const {SlashCommandBuilder} = require("@discordjs/builders");
const {MessageEmbed, MessageActionRow, MessageButton, ButtonStyle} = require("discord.js");
const RedditImageFetcher = require("reddit-image-fetcher");

module.exports = {
  data: new SlashCommandBuilder()
    .setName("meme")
    .setDescription("Xem một bức ảnh chế từ Reddit!"),
  
  run: async (interaction, client) => {

    interaction.reply({content: "Chờ 1 tí..."});

    const row = new MessageActionRow()
      .addComponents(
          new MessageButton()
            .setCustomId('meme-refresh')
            .setLabel('Làm mới')
            .setStyle('SUCCESS'),
          new MessageButton()
            .setCustomId('meme-delete')
            .setLabel('X')
            .setStyle('DANGER')
      )

    RedditImageFetcher.fetch({
      type: 'meme'
    }).then(res => {
      let embed = new MessageEmbed()
        .setColor('RANDOM')
        .setTitle(res[0].title)
        .setURL(res[0].postLink)
        .setImage(res[0].image)
      interaction.editReply(
        {content: " ", embeds: [embed], components: [row]}
      )
    })
    
  }
}